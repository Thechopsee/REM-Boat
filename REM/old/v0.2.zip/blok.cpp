#include "blok.hh"
Blok::Blok(int id,BlokTypeEnum type)
{
    this->id=id;
    this->type=type;
}
