#pragma once
enum BlokTypeEnum
{
controll,
nav,
status 
};
