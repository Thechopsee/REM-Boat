#pragma once
#include <string>
class Nav_module
{
    public:
    virtual std::string getData();
};
